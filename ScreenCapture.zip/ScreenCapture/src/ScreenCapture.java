import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class ScreenCapture{
    Rectangle rect=new Rectangle();
    Robot robot = new Robot();
        public ScreenCapture(Rectangle rect,String outputFolder) throws IOException, AWTException {
            this.rect=rect;
        BufferedImage sc= robot.createScreenCapture(rect);
            String fileName = String.format("%s\\%s.jpg", outputFolder, System.currentTimeMillis());
            File f = null;
            try {
                f = new File(fileName);
                ImageIO.write(sc, "jpg", f);
                Desktop.getDesktop().open(f);
            }
            catch(Exception e) {
                e.printStackTrace();
            }

           /* try {
                Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
                c.setContents(sc, new ClipboardOwner() {
                    @Override
                    public void lostOwnership(Clipboard clipboard, Transferable contents) {
                        // Do nothing
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }*/
            System.exit(0);
        }
    }

